import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks: {
          'job-data': ['./src/constants/jobs.js'],
          'matching': ['./src/services/matchingEngine.js', './src/constants/fieldFamilies.js']
        }
      }
    }
  }
})
