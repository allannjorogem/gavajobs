// Job sectors
export const SECTORS = ["All","Finance","ICT","Legal","Health","Education","Engineering","Supply Chain","Research & M&E","Marketing/Comms","Administration","Social Services","Other"]
